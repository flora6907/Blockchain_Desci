package api

import (
	"encoding/json"
	"net/http"
	"strconv"

	"gin-app/fabric"

	"github.com/gin-gonic/gin"
)

func RegisterAssetRoutes(r *gin.Engine) {
	r.POST("/asset", CreateAsset)
	r.GET("/asset/:id", ReadAsset)
	r.GET("/assets", GetAllAssets)
	r.PUT("/asset/:id", UpdateAsset)       // 新增更新资产接口
	r.DELETE("/asset/:id", DeleteAsset)    // 新增删除资产接口
	r.GET("/assets/owner/:owner", GetAssetByOwner) // 新增按拥有者查询资产接口
	r.POST("/init", InitLedgerHandler)
}

type Asset struct {
	ID             string `json:"ID"`
	Color          string `json:"Color"`
	Size           int    `json:"Size"`
	Owner          string `json:"Owner"`
	AppraisedValue int    `json:"AppraisedValue"`
}

func CreateAsset(c *gin.Context) {
	var req Asset
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	_, err := fabric.Contract.SubmitTransaction("CreateAsset",
		req.ID, req.Color,
		strconv.Itoa(req.Size),
		req.Owner,
		strconv.Itoa(req.AppraisedValue),
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create asset: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Asset created successfully"})
}

func ReadAsset(c *gin.Context) {
	id := c.Param("id")

	result, err := fabric.Contract.EvaluateTransaction("ReadAsset", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read asset: " + err.Error()})
		return
	}

	var asset Asset
	json.Unmarshal(result, &asset)

	c.JSON(http.StatusOK, asset)
}

func GetAllAssets(c *gin.Context) {
	result, err := fabric.Contract.EvaluateTransaction("GetAllAssets")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get all assets: " + err.Error()})
		return
	}

	var assets []Asset
	json.Unmarshal(result, &assets)

	c.JSON(http.StatusOK, assets)
}

// UpdateAsset 用于更新现有资产的属性
func UpdateAsset(c *gin.Context) {
	id := c.Param("id")

	var req Asset
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 使用 SubmitTransaction 提交更新的交易
	_, err := fabric.Contract.SubmitTransaction("UpdateAsset",
		id, req.Color,
		strconv.Itoa(req.Size),
		req.Owner,
		strconv.Itoa(req.AppraisedValue),
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update asset: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Asset updated successfully"})
}

// DeleteAsset 用于删除指定 ID 的资产
func DeleteAsset(c *gin.Context) {
	id := c.Param("id")

	// 使用 SubmitTransaction 提交删除资产的交易
	_, err := fabric.Contract.SubmitTransaction("DeleteAsset", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete asset: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Asset deleted successfully"})
}

// GetAssetByOwner 用于根据拥有者查询资产列表
func GetAssetByOwner(c *gin.Context) {
	owner := c.Param("owner")

	// 使用 EvaluateTransaction 查询指定拥有者的资产
	result, err := fabric.Contract.EvaluateTransaction("GetAssetByOwner", owner)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get assets by owner: " + err.Error()})
		return
	}

	var assets []Asset
	json.Unmarshal(result, &assets)

	c.JSON(http.StatusOK, assets)
}

// InitLedgerHandler 调用 Fabric 链码的 InitLedger 函数
func InitLedgerHandler(c *gin.Context) {
	_, err := fabric.Contract.SubmitTransaction("InitLedger")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to initialize ledger: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Ledger initialized successfully"})
}

