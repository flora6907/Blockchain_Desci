<?php
$lastResult = null;
$submittedData = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST["action"];
    $id = $_POST["id"];
    $url = "http://localhost:8080/asset";
    $ch = curl_init();

    if ($action === "create" || $action === "update") {
        $data = array(
            "ID" => $id,
            "Color" => $_POST["color"],
            "Size" => (int)$_POST["size"],
            "Owner" => $_POST["owner"],
            "AppraisedValue" => (int)$_POST["value"]
        );
        $jsonData = json_encode($data);
        $submittedData = $data;

        curl_setopt($ch, CURLOPT_URL, $url . ($action === "update" ? "/$id" : ""));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $action === "update" ? "PUT" : "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);
    } elseif ($action === "delete") {
        $submittedData = ["ID" => $id];
        curl_setopt($ch, CURLOPT_URL, $url . "/$id");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $lastResult = [
        "status" => $httpCode,
        "response" => $response,
        "action" => $action
    ];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>资产操作</title>
    <style>
        body {
            font-family: Arial;
            margin: 40px;
        }
        .hidden { display: none; }
        .form-section {
            margin-bottom: 30px;
        }
        label {
            display: inline-block;
            width: 150px;
        }
        input[type="text"], input[type="number"] {
            width: 200px;
            padding: 5px;
        }
        input[type="submit"], .button-link {
            padding: 10px 20px;
            font-size: 16px;
            margin-top: 10px;
            margin-right: 10px;
            cursor: pointer;
        }
        .button-link {
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }
        .button-link:hover {
            background-color: #0056b3;
        }
        .card {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 8px;
            background: #f9f9f9;
            max-width: 600px;
            margin-top: 20px;
        }
    </style>
    <script>
        function showForm(action) {
            document.getElementById("action").value = action;
            document.getElementById("form-container").classList.remove("hidden");
            document.getElementById("operation-buttons").classList.add("hidden");

            // Adjust fields
            const colorField = document.getElementById("color-field");
            const sizeField = document.getElementById("size-field");
            const ownerField = document.getElementById("owner-field");
            const valueField = document.getElementById("value-field");

            const showFields = (action === "create" || action === "update");
            colorField.style.display = showFields ? "block" : "none";
            sizeField.style.display = showFields ? "block" : "none";
            ownerField.style.display = showFields ? "block" : "none";
            valueField.style.display = showFields ? "block" : "none";
        }

        function resetToSelection() {
            document.getElementById("form-container").classList.add("hidden");
            document.getElementById("operation-buttons").classList.remove("hidden");
            document.getElementById("asset-form").reset();
        }
    </script>
</head>
<body>

<h1>资产链码操作</h1>

<div id="operation-buttons">
    <button onclick="showForm('create')">新增资产</button>
    <button onclick="showForm('update')">修改资产</button>
    <button onclick="showForm('delete')">删除资产</button>
</div>

<div id="form-container" class="hidden">
    <form method="POST" id="asset-form">
        <input type="hidden" name="action" id="action">
        <div class="form-section">
            <label>ID:</label>
            <input type="text" name="id" required><br><br>

            <div id="color-field">
                <label>Color:</label>
                <input type="text" name="color"><br><br>
            </div>
            <div id="size-field">
                <label>Size:</label>
                <input type="number" name="size"><br><br>
            </div>
            <div id="owner-field">
                <label>Owner:</label>
                <input type="text" name="owner"><br><br>
            </div>
            <div id="value-field">
                <label>Appraised Value:</label>
                <input type="number" name="value"><br><br>
            </div>

            <input type="submit" value="提交">
            <button type="button" onclick="resetToSelection()">返回</button>
        </div>
    </form>
</div>

<?php if ($lastResult): ?>
    <?php
        $isSuccess = $lastResult["status"] >= 200 && $lastResult["status"] < 300;
        $cardColor = $isSuccess ? "#e0f7e9" : "#fbeaea";
        $borderColor = $isSuccess ? "#28a745" : "#dc3545";
        $title = $isSuccess ? "✅ 操作成功" : "❌ 操作失败";
    ?>
    <div class="card" style="background-color: <?= $cardColor ?>; border-color: <?= $borderColor ?>;">
        <h3 style="color: <?= $borderColor ?>"><?= $title ?>（<?= strtoupper(htmlspecialchars($lastResult["action"])) ?>）</h3>
        <strong>状态码:</strong> <?= htmlspecialchars($lastResult["status"]) ?><br><br>

        <strong>提交数据:</strong>
        <pre style="white-space: pre-wrap; word-wrap: break-word; font-size: 14px;">
<?= htmlspecialchars(json_encode($submittedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?>
        </pre>

        <strong>链码返回:</strong>
        <pre style="white-space: pre-wrap; word-wrap: break-word; font-size: 14px;">
<?= htmlspecialchars(json_encode(json_decode($lastResult["response"]), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?: $lastResult["response"]) ?>
        </pre>
    </div>
<?php endif; ?>


</body>
</html>
